@php
    $documentBrand = app(\App\Services\DocumentBranding::class)->resolve();
@endphp
<!doctype html><html><head><meta charset="utf-8"><style>@page{margin:24px}body{font-family:DejaVu Sans,sans-serif;color:#263943;font-size:9px}h1{text-align:center;color:#123d57}table{width:100%;border-collapse:collapse}th{background:#173b54;color:#fff;padding:6px}td{border:1px solid #ced8de;padding:5px}.root{background:#e8f4f2;font-weight:bold}.child td:first-child{padding-left:14px}.activity td:first-child{padding-left:25px}.center{text-align:center}</style>@include('edr_plans.partials.branding')
</head><body>
@include('edr_plans.partials.header')
<h1>{{ $title }}</h1><table><thead><tr><th>Code</th><th>Objective / Activity</th><th>KPI Code</th><th>Unit</th><th>Baseline</th><th>Weight</th><th>Annual Target</th><th>Lead / Implementing Department</th></tr></thead><tbody>@foreach($objectives as $root)@include('edr_plans._objective_pdf_branch',['objective'=>$root,'depth'=>0])@endforeach</tbody></table></body></html>
