# Approved plan export branding

PDF downloads for organization plans, department plans and individual objectives now use a shared branded header, footer, section colors and table colors. Generated organization-plan Word documents use the same logo, name, abbreviation and color palette. Uploaded attachments are downloaded in their original form.

Choose Settings > Logo & Branding > Document Brand Color. Default: #277967, matching the system logo. Uploaded PNG/JPEG logos are embedded from private server-local paths; no external image download or public storage symlink is required by the PDF/Word exporter. Fallback: public/images/system-logo.png.

Upload the following files to their matching paths in the deployed Laravel project, then clear compiled Blade views. No database migration or Composer update is required. Existing plan data is unchanged.

- app/Services/DocumentBranding.php
- app/Services/OrganizationPlanWordExporter.php
- app/Http/Controllers/SettingController.php
- resources/views/settings/index.blade.php
- resources/views/edr_plans/organization_approved_plans_pdf.blade.php
- resources/views/edr_plans/organization_plan_pdf.blade.php
- resources/views/edr_plans/plan_pdf.blade.php
- resources/views/edr_plans/objectives_pdf.blade.php
- resources/views/edr_plans/partials/branding.blade.php
- resources/views/edr_plans/partials/header.blade.php
- public/images/system-logo.png

Verification: EdrPlanDocumentTest covers existing PDF downloads and Word branding; a multi-page PDF is rendered for layout review. Test fixture exports under tmp/pdfs are samples, not real approved reports.
