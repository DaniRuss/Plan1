@php
    $exportLayout=app(\App\Services\ApprovedPlanExport::class);
    $periodColumns=\App\Services\ApprovedPlanExport::PERIODS;
@endphp
<table><thead><tr><th>Code</th><th>Planned Activity / KPI</th><th>Unit</th><th>Planning Baseline</th><th>Approved Weight</th><th>Annual Plan</th>
@foreach($periodColumns as $period=>$label)<th @if(str_starts_with($period,'q')) class="quarter-heading" @endif>{{ $label }} Plan</th>@endforeach
<th>Implementing Departments</th></tr></thead><tbody>
@forelse($schedulePlans as $schedulePlan)
@if($schedulePlans->pluck('department_id')->unique()->count() > 1)
<tr><td colspan="23" class="dept">{{ $schedulePlan->department->name }}</td></tr>
@endif
@foreach(($scheduleItems ?? $schedulePlan->items)->sortBy(fn($item)=>$item->strategicObjective?->code,SORT_NATURAL) as $scheduleItem)
@php
    $scheduleObjective=$scheduleItem->strategicObjective;
    $implementers=$exportLayout->implementers($scheduleItem,$departmentNames,$schedulePlan->department_id);
@endphp
<tr><td>{{ $scheduleObjective?->code }}</td><td class="desc">{{ $scheduleObjective?->description }}</td><td>{{ $scheduleItem->unit ?: $scheduleObjective?->unit }}</td><td>{{ \App\Support\NumberFormatter::format($scheduleItem->baseline_value ?? $scheduleObjective?->baseline_value ?? '-') }}</td><td>{{ \App\Support\NumberFormatter::format($scheduleItem->weight ?: $scheduleObjective?->weight) }}%</td><td>{{ \App\Support\NumberFormatter::format($scheduleItem->annual_target ?? '-') }}</td>
@foreach($periodColumns as $period=>$label)<td @if(str_starts_with($period,'q')) class="q" @endif>{{ \App\Support\NumberFormatter::format($scheduleItem->{$period.'_target'} ?? '-') }}</td>@endforeach
<td class="implementers">@forelse($implementers as $name)<div>@if($loop->first)<strong>{{ $name }}</strong>@else{{ $name }}@endif</div>@empty{{ $schedulePlan->department->name }}@endforelse</td></tr>
@endforeach
@empty<tr><td colspan="23">No approved action-plan items.</td></tr>@endforelse
</tbody></table>
