@php
    $documentBrand = app(\App\Services\DocumentBranding::class)->resolve();
@endphp
<!doctype html><html><head><meta charset="utf-8"><style>@page{margin:22px}body{font-family:DejaVu Sans,sans-serif;color:#24343f;font-size:9px}h1{text-align:center;color:#123d57;margin-bottom:3px}h2{color:#087f77;border-bottom:2px solid #087f77;padding-bottom:4px;margin-top:18px}.meta{text-align:center;color:#667780;margin-bottom:20px}.text{white-space:pre-line;line-height:1.6;text-align:justify}.empty{color:#999;font-style:italic}.page{page-break-before:always}table{width:100%;border-collapse:collapse;font-size:6.5px}th{background:#173b54;color:#fff;padding:4px}td{border:1px solid #cfd9df;padding:3px;text-align:center}td.desc{text-align:left;width:155px}.dept{background:#dff1ee;font-weight:bold;text-align:left}.q{background:#e9f4f8;font-weight:bold}.summary{font-size:8px;margin-top:8px}.summary td{padding:5px}.summary .objective{text-align:left}.summary .level-1{padding-left:14px}.summary .level-2{padding-left:25px;color:#536773}.footer{margin-top:12px;color:#6d7b84}</style>@include('edr_plans.partials.branding')
</head><body>
@include('edr_plans.partials.header')

<h1>ORGANIZATION EDR PLAN</h1><div class="meta">Complete Approved Plan · {{ $year }} EFY · {{ $plans->count() }} Departmental Plans</div>
@foreach([['1. Introduction','introduction'],['2. Past Year’s Performance, Strengths, Weaknesses and Future Focus Areas','past_performance'],['3. Strategic Issues (Vision, Mission, Values and Goals)','strategic_issues']] as [$heading,$field])<h2>{{ $heading }}</h2><div class="text {{ blank($narrative?->$field) ? 'empty':'' }}">{{ $narrative?->$field ?: 'Narration has not yet been prepared for this plan year.' }}</div>@endforeach
<h2>4. Objectives and Detailed Activities</h2>
<p>The following objectives and detailed activities are generated automatically from every approved departmental plan.</p>
<table class="summary"><thead><tr><th>Code</th><th>Objective / Detailed Activity</th><th>Measurement</th><th>Weight</th><th>Implementing Departments</th></tr></thead><tbody>
@forelse($plans as $plan)
 <tr><td colspan="5" class="dept">{{ $plan->department->name }}</td></tr>
 @foreach($plan->items->sortBy(fn($item)=>$item->strategicObjective?->code) as $item)
  @php($objective=$item->strategicObjective)
  @php($level=$objective?->getHierarchyLevel() ?? 0)
  @php($summaryBodies=implode('; ',app(\App\Services\ApprovedPlanExport::class)->implementers($item,$departmentNames,$plan->department_id)))
  <tr><td>{{ $objective?->code }}</td><td class="objective level-{{ min(2,$level) }}">{{ $objective?->description }}</td><td>{{ $item->unit?:$objective?->unit }}</td><td>{{ \App\Support\NumberFormatter::format($item->weight?:$objective?->weight) }}%</td><td>{{ $summaryBodies?:$plan->department->name }}</td></tr>
 @endforeach
@empty<tr><td colspan="5">No approved objectives or detailed activities exist for this plan year.</td></tr>@endforelse
</tbody></table>
@foreach([['5. Implementation Strategies','implementation_strategies'],['6. Monitoring and Evaluation System','monitoring_evaluation'],['7. Challenges and Possible Solutions','challenges_solutions']] as [$heading,$field])<h2>{{ $heading }}</h2><div class="text {{ blank($narrative?->$field) ? 'empty':'' }}">{{ $narrative?->$field ?: 'Narration has not yet been prepared for this plan year.' }}</div>@endforeach
<h2 class="page">8. Approved Action Plan Schedule (Plan Only)</h2><p>This section contains approved targets only. It does not contain actual performance or achievement results.</p>@include('edr_plans.partials.schedule', ['schedulePlans'=>$plans])<div class="footer">Narration prepared by: {{ $narrative?->preparer?->name??'Not recorded' }} · Generated {{ now()->format('d M Y H:i') }}</div></body></html>
