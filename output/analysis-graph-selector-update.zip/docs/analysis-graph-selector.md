# Analysis graph selector

Applies to Performance Comparison, Dashboard Analytics and KPI Performance Board. All existing charts default to Bar graph, with Line graph, Pie chart, Histogram and Frequency polygon options. Existing filters and displayed data scope are retained; comparison still uses the first 12 filtered KPIs.

Bar/line charts show original category values. Histograms and frequency polygons count recorded numeric values in five shared equal-width bins (one bin for constant data), retaining zeros and excluding missing data. Polygon points use numeric bin midpoints and close at zero. Pie charts for comparison/measurement data show the same frequency counts; each ring is one series. Originally categorical pie/doughnut charts retain their original composition when Pie is selected. Short help text explains each view.

Upload public/js/analysis-graphs.js and resources/views/layouts/app.blade.php to matching paths. No migrations or dependency updates. Clear generated PHP files from storage/framework/views, retaining the directory and .gitignore, then refresh the page. Script URLs use a file timestamp to refresh cached JavaScript.

Verification: JavaScript tests cover switching, immutable source data, shared bins, upper boundaries, zero/missing values, numeric strings, empty and constant datasets, polygon geometry, and mounting controls. Existing comparison/dashboard feature tests pass. No live-server browser verification has been performed.
