(function (root) {
    'use strict';
    const palette = ['#078f83','#315b7c','#f2b84b','#db5560','#52a7c1','#8a6fc2'];
    const numeric = value => typeof value === 'number' && Number.isFinite(value);
    const copy = value => JSON.parse(JSON.stringify(value));

    function buildGraph(source, mode = 'bar', horizontal = false, composition = false) {
        const data = copy(source);
        data.datasets.forEach(d => { d.data = d.data.map(value => typeof value === 'string' && value.trim() !== '' && Number.isFinite(Number(value)) ? Number(value) : value); });
        const options = {responsive:true, maintainAspectRatio:false, plugins:{legend:{position:'bottom',labels:{usePointStyle:true}}}};
        let type = mode === 'line' || mode === 'polygon' ? 'line' : mode === 'pie' ? 'pie' : 'bar';
        let note = 'Original values by category. Missing results are left blank.';
        if (mode === 'histogram' || mode === 'polygon' || (mode === 'pie' && !composition)) {
            const values = data.datasets.flatMap(d => d.data).filter(numeric);
            const min = values.length ? Math.min(...values) : 0;
            const max = values.length ? Math.max(...values) : 1;
            const count = min === max ? 1 : 5;
            const width = min === max ? Math.max(1, Math.abs(min) * .1) : (max - min) / count;
            const start = min === max ? min - width / 2 : min;
            const format = value => Number(value.toPrecision(5)).toLocaleString();
            data.labels = Array.from({length:count}, (_,i) => `${format(start+i*width)} to ${format(start+(i+1)*width)}${i === count-1 ? ' (inclusive)' : ''}`);
            data.datasets = data.datasets.map((d, series) => {
                const bins = Array(count).fill(0);
                d.data.filter(numeric).forEach(value => bins[Math.min(count-1, Math.max(0, Math.floor((value-start)/width)))]++);
                const points = bins.map((value,i) => ({x:start+(i+.5)*width,y:value}));
                if (mode === 'polygon') {
                    points.unshift({x:start-width/2,y:0});
                    points.push({x:start+(count+.5)*width,y:0});
                }
                return {label:d.label || `Series ${series+1}`, data:mode === 'polygon' ? points : bins,
                    backgroundColor:mode === 'pie' ? palette : palette[series % palette.length],
                    borderColor:mode === 'pie' ? '#fff' : palette[series % palette.length],
                    borderWidth:2, fill:false, tension:0, barPercentage:1, categoryPercentage:1};
            });
            note = 'Distribution of recorded values in equal-width ranges; missing values excluded. Ranges include their lower boundary; only the final range includes its upper boundary.';
            if (mode === 'pie') note += ' Each ring represents one series; slices show counts of results, not sums of percentages.';
            else options.scales = {x:{type:mode === 'polygon' ? 'linear' : 'category', title:{display:true,text:'Value range'}},y:{beginAtZero:true,title:{display:true,text:'Number of results'},ticks:{precision:0}}};
        } else {
            data.datasets = data.datasets.map((d,i) => ({label:d.label || 'Results',data:d.data,
                backgroundColor:mode === 'pie' ? (Array.isArray(d.backgroundColor) ? d.backgroundColor : palette) : (d.backgroundColor || palette[i % palette.length]),
                borderColor:mode === 'pie' ? '#fff' : palette[i % palette.length],borderWidth:2,fill:false,tension:0,spanGaps:false}));
            if (mode === 'pie') note = 'Share of the original category totals. Each ring represents one series.';
            else {
                options.indexAxis = mode === 'bar' && horizontal ? 'y' : 'x';
                options.scales = {x:{beginAtZero:options.indexAxis === 'y'}, y:{beginAtZero:options.indexAxis !== 'y'}};
            }
        }
        return {type,data,options,note};
    }

    function mount(ChartClass, document) {
        document.querySelectorAll('canvas').forEach(canvas => {
            const original = ChartClass.getChart(canvas);
            if (!original || canvas.dataset.graphSelector) return;
            canvas.dataset.graphSelector = '1';
            const source = copy(original.data);
            const horizontal = original.options.indexAxis === 'y';
            const composition = ['pie','doughnut'].includes(original.config.type);
            const controls = document.createElement('section');
            controls.className = 'analysis-graph-controls';
            const label = document.createElement('label');
            label.textContent = 'Graph type';
            const select = document.createElement('select');
            select.className = 'form-control form-control-sm';
            select.setAttribute('aria-label', `Graph type for ${canvas.id || 'analysis'}`);
            [['bar','Bar graph'],['line','Line graph'],['pie','Pie chart'],['histogram','Histogram'],['polygon','Frequency polygon']].forEach(([value,text]) => {
                const option = document.createElement('option'); option.value=value; option.textContent=text; select.appendChild(option);
            });
            label.appendChild(select); controls.appendChild(label);
            const note = document.createElement('small');
            note.className = 'text-muted'; note.setAttribute('aria-live','polite'); controls.appendChild(note);
            // Keep controls outside the dedicated responsive canvas container.
            const host = canvas.parentElement;
            host.parentElement.insertBefore(controls, host);
            let chart = original;
            function render() {
                const graph = buildGraph(source, select.value, horizontal, composition);
                chart.destroy();
                chart = new ChartClass(canvas, {type:graph.type,data:graph.data,options:graph.options});
                note.textContent = graph.note;
            }
            select.addEventListener('change', render);
            render();
        });
    }
    if (typeof module !== 'undefined' && module.exports) module.exports = {buildGraph,mount};
    if (root.document) {
        const ready = () => { if (root.Chart) mount(root.Chart, root.document); };
        if (root.document.readyState === 'loading') root.document.addEventListener('DOMContentLoaded', ready);
        else ready();
    }
})(typeof window !== 'undefined' ? window : globalThis);
